<?php
$lang = 'en';
?>