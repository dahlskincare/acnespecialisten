function onReadMoreClick() {
    //let button = event.target as Element;
    var collapsed = document.querySelector('#problems-banner-collapsed');
    collapsed.remove();
    document.querySelector('#problems-banner-expanded').classList.remove('is-hidden');
}
//# sourceMappingURL=problems.js.map